export class Product {
     productId:number;
	 productName:string;  
	 price: number;
	 color: string;
	 manufacturer:string;
	 quantity:number;
}
