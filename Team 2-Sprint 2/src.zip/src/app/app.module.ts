import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewAllCustomersComponent } from './view-all-customers/view-all-customers.component';
import { HttpClientModule } from '@angular/common/http';
import { AddCustomerComponent } from './add-customer/add-customer.component'
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { ViewAllOrdersComponent } from './view-all-orders/view-all-orders.component';
import { AddOrderComponent } from './add-order/add-order.component';
import { UpdateOrderComponent } from './update-order/update-order.component';
import { ViewAllProductsComponent } from './view-all-products/view-all-products.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    ViewAllCustomersComponent,
    AddCustomerComponent,
    UpdateCustomerComponent,
    ViewAllOrdersComponent,
    AddOrderComponent,
    UpdateOrderComponent,
    ViewAllProductsComponent,
    UpdateProductComponent,
    AddProductComponent,
    LoginComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
