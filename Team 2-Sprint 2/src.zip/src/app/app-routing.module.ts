import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddOrderComponent } from './add-order/add-order.component';
import { AddProductComponent } from './add-product/add-product.component';
import { LoginComponent } from './login/login.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateOrderComponent } from './update-order/update-order.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { ViewAllCustomersComponent } from './view-all-customers/view-all-customers.component';
import { ViewAllOrdersComponent } from './view-all-orders/view-all-orders.component';
import { ViewAllProductsComponent } from './view-all-products/view-all-products.component';
const routes: Routes = [
  {path:'customers',component:ViewAllCustomersComponent},
  {path:'addcustomer',component:AddCustomerComponent},
  {path:'updatecustomer/:customerId',component:UpdateCustomerComponent},
  {path:'login',component:LoginComponent},
  {path: '',redirectTo: 'login',pathMatch:'full'},


  {path:'orders',component:ViewAllOrdersComponent},
  {path:'addorder',component:AddOrderComponent},
  {path:'updateorder/:orderId',component:UpdateOrderComponent},


  {path:'products',component:ViewAllProductsComponent},
  {path:'addproduct',component:AddProductComponent},
  {path:'updateproduct/:productId',component:UpdateProductComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
