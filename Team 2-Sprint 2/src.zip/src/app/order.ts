export class Order {
    orderId: number;
   orderStatus: string;
}
