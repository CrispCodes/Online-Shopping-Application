import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer'
@Injectable({
  providedIn: 'root'
})
export class CustomerService {
private baseURL="http://localhost:9001/customer/viewCustomerList";
private baseURL1="http://localhost:9001/customer/addCustomer";
private baseURL2="http://localhost:9001/customer/updateCustomer";
private baseURL3="http://localhost:9001/customer/removeCustomer";
  constructor(private httpClient: HttpClient) { }
  getCustomersList(): Observable<Customer[]>{
    return this.httpClient.get<Customer[]>(`${this.baseURL}`);
  }
  addCustomer(customer: Customer):Observable<Object>{
    return this.httpClient.post(`${this.baseURL1}`,customer);
  }
  getCustomerById(customerId: number): Observable<Customer>
  {
    return this.httpClient.get<Customer>(`http://localhost:9091/viewCustomer/${customerId}`);
  }

  updateCustomer(customerId: number,customer:Customer):Observable<any>
  {
    return this.httpClient.put(`${this.baseURL2}/${customerId}`,customer);
  }
  removeCustomer(customerId: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL3}/${customerId}`);
  }
}
 