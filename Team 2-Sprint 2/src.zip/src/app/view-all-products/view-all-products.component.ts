import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-view-all-products',
  templateUrl: './view-all-products.component.html',
  styleUrls: ['./view-all-products.component.css']
})
export class ViewAllProductsComponent implements OnInit {

  products: Product[];
  constructor(private productService: ProductService,
    private router:Router) { }

  ngOnInit(): void {
    this.getProducts();
  }
private getProducts(){
  this.productService.getProductsList().subscribe(data => 
    {this.products=data;}
    );
}
updateProduct(productId: number){
this.router.navigate(['updateproduct',productId]);
}
removeProduct(productId:number){
  this.productService.removeProduct(productId).subscribe(data =>{
    console.log(data);
    this.getProducts();
  })
}
}
