import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private baseURL="http://localhost:9001/viewOrderList";
  private baseURL1="http://localhost:9001/addOrder";
  private baseURL2="http://localhost:9001/updateOrder";
  private baseURL3="http://localhost:9001/deleteOrder";
    constructor(private httpClient: HttpClient) { }

    getOrdersList(): Observable<Order[]>{
      return this.httpClient.get<Order[]>(`${this.baseURL}`);
    }
    addOrder(order: Order):Observable<Object>{
      return this.httpClient.post(`${this.baseURL1}`,order);
    }
    getOrderById(orderId: number): Observable<Order>
    {
      return this.httpClient.get<Order>(`http://localhost:9091/viewOrder/${orderId}`);
    }
  
    updateOrder(orderId: number,order:Order):Observable<any>
    {
      return this.httpClient.put(`${this.baseURL2}/${orderId}`,order);
    }
    removeOrder(orderId: number): Observable<Object>{
      return this.httpClient.delete(`${this.baseURL3}/${orderId}`);
    }
  }
 

