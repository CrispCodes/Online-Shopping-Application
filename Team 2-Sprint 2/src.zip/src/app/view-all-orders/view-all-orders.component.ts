import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-view-all-orders',
  templateUrl: './view-all-orders.component.html',
  styleUrls: ['./view-all-orders.component.css']
})
export class ViewAllOrdersComponent implements OnInit {

  orders: Order[];
  constructor(private orderService: OrderService,
    private router:Router) { }
  ngOnInit(): void {
    this.getOrders();
  }
private getOrders(){
  this.orderService.getOrdersList().subscribe(data => 
    {this.orders=data;}
    );
}
updateOrder(orderId: number){
this.router.navigate(['updateorder',orderId]);
}
removeOrder(orderId:number){
  this.orderService.removeOrder(orderId).subscribe(data =>{
    console.log(data);
    this.getOrders();
  })
}
}

