import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseURL="http://localhost:9001/product/viewProductList";
  private baseURL1="http://localhost:9001/product/addProduct";
  private baseURL2="http://localhost:9001/product/updateProduct";
  private baseURL3="http://localhost:9001/product/removeProduct";
    constructor(private httpClient: HttpClient) { }

    getProductsList(): Observable<Product[]>{
      return this.httpClient.get<Product[]>(`${this.baseURL}`);
    }
    addProduct(product: Product):Observable<Object>{
      return this.httpClient.post(`${this.baseURL1}`,product);
    }
    getProductById(productId: number): Observable<Product>
    {
      return this.httpClient.get<Product>(`http://localhost:9091/viewProduct/${productId}`);
    }
  
    updateProduct(productId: number,product:Product):Observable<any>
    {
      return this.httpClient.put(`${this.baseURL2}/${productId}`,product);
    }
    removeProduct(productId: number): Observable<Object>{
      return this.httpClient.delete(`${this.baseURL3}/${productId}`);
    }
  }
 


