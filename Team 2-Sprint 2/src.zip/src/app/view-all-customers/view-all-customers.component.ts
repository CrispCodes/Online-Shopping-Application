import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-all-customers',
  templateUrl: './view-all-customers.component.html',
  styleUrls: ['./view-all-customers.component.css']
})
export class ViewAllCustomersComponent implements OnInit {
  customers: Customer[];
  constructor(private customerService: CustomerService,
    private router:Router) { }

  ngOnInit(): void {
    this.getCustomers();
  }
private getCustomers(){
  this.customerService.getCustomersList().subscribe(data => 
    {this.customers=data;}
    );
}
updateCustomer(customerId: number){
this.router.navigate(['updatecustomer',customerId]);
}
removeCustomer(customerId:number){
  this.customerService.removeCustomer(customerId).subscribe(data =>{
    console.log(data);
    this.getCustomers();
  })
}
}
