export class Customer {
   customerId: number;
   firstName: string;
   lastName: string;
   mobileNumber: string;
   email: string;
   addressId: string; 
}
