import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-update-order',
  templateUrl: './update-order.component.html',
  styleUrls: ['./update-order.component.css']
})
export class UpdateOrderComponent implements OnInit {
  order: Order  = new Order();
  orderId!: number;
  constructor(private orderService : OrderService,
    private route: ActivatedRoute,
    private router : Router) { }
   
  ngOnInit(): void {

    this.orderId = this.route.snapshot.params['orderId'];
    this.orderService.getOrderById(this.orderId).subscribe(data => {
      this.order = data;
    }, error  => console.log(error)
      );
  }


  onSubmit()
  {
    this.orderService.updateOrder(this.orderId,this.order).subscribe(data => {
    this.goToOrderList();
    } );
  }

 goToOrderList()
 {
   this.router.navigate(['/orders']);
 }
}