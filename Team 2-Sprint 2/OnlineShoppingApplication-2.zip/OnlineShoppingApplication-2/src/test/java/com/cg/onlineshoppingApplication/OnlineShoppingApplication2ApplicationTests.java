package com.cg.onlineshoppingApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShoppingApplication2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
