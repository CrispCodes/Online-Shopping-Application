package com.cg.onlineshoppingApplication.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.cg.onlineshoppingApplication.entities.Order;
import com.cg.onlineshoppingApplication.entities.Product;

public interface IProductService {
	  public List<Product> ViewAllProducts();
	  public Product addProduct(Product product);
	  public ResponseEntity<Product> updateProduct(int productId,Product pdt);
	  public ResponseEntity<Product> viewProduct(int productId);
	  public ResponseEntity<Map<String,Boolean>> removeProduct(int productId);
}
