package com.cg.onlineshoppingApplication.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.cg.onlineshoppingApplication.entities.Customer;

import java.util.Optional;
public interface ICustomerService {
	  public Customer addCustomer(Customer cust);
	  public ResponseEntity<Customer> updateCustomer(int customerId,Customer cust);
	  public ResponseEntity<Map<String,Boolean>> removeCustomer(int customerId);
	  public ResponseEntity<Customer> viewCustomer(int customerId);
	  public List<Customer> ViewAllCustomers();
	 
}
