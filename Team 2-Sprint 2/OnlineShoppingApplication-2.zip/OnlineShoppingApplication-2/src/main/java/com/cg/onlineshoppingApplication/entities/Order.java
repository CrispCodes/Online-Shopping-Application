package com.cg.onlineshoppingApplication.entities;

import java.time.LocalDate;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "order_table")
public class Order {

	@Id
	 @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="orders_generator")
	 @SequenceGenerator(name="orders_generator",sequenceName = "orders_seq",allocationSize = 5)
	private int orderId;
    private String orderStatus;

	
	public  Order() 
	{}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
}
