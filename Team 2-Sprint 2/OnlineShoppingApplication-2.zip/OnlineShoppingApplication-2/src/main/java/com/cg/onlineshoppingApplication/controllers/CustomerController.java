package com.cg.onlineshoppingApplication.controllers;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshoppingApplication.entities.Customer;
import com.cg.onlineshoppingApplication.services.ICustomerServiceImpl;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins="*")
public class CustomerController {
	
	@Autowired //Autowiring feature of spring framework enables you to inject the object dependency implicitly
	private ICustomerServiceImpl custservice;
	@GetMapping("/check")
	public String check() {
		return "ok";
	}
	  @PostMapping("/addCustomer")
	  public Customer addCustomer(@RequestBody Customer cust) 
	  { System.out.println("New Customer is added"); 
	  return custservice.addCustomer(cust); }
	  
	  @GetMapping("/viewCustomer/{customerId}")
	  public ResponseEntity<Customer> viewCustomer(@PathVariable int customerId) {
		  return custservice.viewCustomer(customerId);
		  }
	  @PutMapping("/updateCustomer/{customerId}") 
	  public ResponseEntity<Customer> updateCustomer(@PathVariable int customerId,@RequestBody Customer cust) 
	  { 
		  return custservice.updateCustomer(customerId,cust); 
	  }
	 
	  @GetMapping("/viewCustomerList") 
	  public List<Customer> ViewAllCustomers() {
	 
	  return custservice.ViewAllCustomers(); }
	  
	  @DeleteMapping("/removeCustomer/{customerId}") 
	  public ResponseEntity<Map<String,Boolean>> removeCustomer(@PathVariable int customerId)
	  {
	  return custservice.removeCustomer(customerId);
	  }
}
