package com.cg.onlineshoppingApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoppingApplication2Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShoppingApplication2Application.class, args);
		System.out.println("Server Started!..");
	}

}
