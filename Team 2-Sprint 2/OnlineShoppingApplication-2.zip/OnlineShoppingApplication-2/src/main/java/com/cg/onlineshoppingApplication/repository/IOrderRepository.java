package com.cg.onlineshoppingApplication.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlineshoppingApplication.entities.Customer;
import com.cg.onlineshoppingApplication.entities.Order;

@Repository
public interface IOrderRepository extends JpaRepository<Order,Integer>
{
	 
}
