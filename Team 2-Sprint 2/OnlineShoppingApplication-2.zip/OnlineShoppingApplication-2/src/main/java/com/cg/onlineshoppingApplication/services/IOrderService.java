package com.cg.onlineshoppingApplication.services;


import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.onlineshoppingApplication.entities.Customer;
import com.cg.onlineshoppingApplication.entities.Order;

public interface IOrderService {
	public Order addOrder(Order order);
	 public ResponseEntity<Order> updateOrder(int orderId,Order odr);
	 public ResponseEntity<Map<String,Boolean>> removeOrder(int orderId);
	 public ResponseEntity<Order> viewOrder(int orderId);
	 public List<Order> ViewAllOrders();
}
