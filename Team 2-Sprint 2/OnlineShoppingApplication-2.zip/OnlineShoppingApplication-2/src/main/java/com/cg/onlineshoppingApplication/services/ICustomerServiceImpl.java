package com.cg.onlineshoppingApplication.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.onlineshoppingApplication.entities.Customer;
import com.cg.onlineshoppingApplication.exception.ResourceNotFoundException;
import com.cg.onlineshoppingApplication.repository.ICustomerRepository;


@Service //annotation is used with classes that provide some business functionalities.
@Transactional
public class ICustomerServiceImpl implements ICustomerService {
	
@Autowired 
ICustomerRepository custRepo;


  @Override
  
  public Customer addCustomer(Customer cust) { 
	  Customer custadd=custRepo.save(cust);
	  return custadd; 
	  }
  
	
	  @Override 
	  public ResponseEntity<Customer> updateCustomer(int customerId,Customer cust) { 
		  Customer custupdate=custRepo.findById(customerId)
				  .orElseThrow(()->new ResourceNotFoundException("Customer does not exist with ID : "+ customerId));
		  custupdate.setFirstName(cust.getFirstName());
		  custupdate.setLastName(cust.getLastName());
		  custupdate.setMobileNumber(cust.getMobileNumber());
		  custupdate.setEmail(cust.getEmail());
		  custupdate.setAddressId(cust.getAddressId());
		  Customer updatedCustomer=custRepo.save(custupdate);
		  return ResponseEntity.ok(updatedCustomer); 
		  }
	 
 	 @Override
     public ResponseEntity<Map<String,Boolean>> removeCustomer(int customerId){
 		Customer custremove=custRepo.findById(customerId)
 				  .orElseThrow(()->new ResourceNotFoundException("Customer does not exist with ID : "+ customerId));
 		  custRepo.delete(custremove);
 		  Map<String,Boolean> response=new HashMap<>();
 		  response.put("Customer record deleted",Boolean.TRUE);
 		  return ResponseEntity.ok(response) ;
  }
	
	  @Override 
	  public ResponseEntity<Customer> viewCustomer(int customerId) {
	  Customer custview=custRepo.findById(customerId)
			  .orElseThrow(()->new ResourceNotFoundException("Customer does not exist with ID : "+ customerId));
	  return ResponseEntity.ok(custview) ;
	  }
	 
 
	
	  @Override
	  public List<Customer> ViewAllCustomers() {
	  List<Customer> viewcust=custRepo.findAll(); 
	  return viewcust; 
	  }
	 
	 


}
