package com.cg.onlineshoppingApplication.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.onlineshoppingApplication.entities.Order;
import com.cg.onlineshoppingApplication.entities.Product;
import com.cg.onlineshoppingApplication.exception.ResourceNotFoundException;
import com.cg.onlineshoppingApplication.repository.IProductRepository;

@Service
public class IProductServiceImpl implements IProductService 
{
	@Autowired
	IProductRepository productRepo;
	 public List<Product> ViewAllProducts() {
		  List<Product> viewpdt=productRepo.findAll(); 
		  return viewpdt; 
		  }
	 public Product addProduct(Product product)
	 {
		Product add =productRepo.save(product);
		return add;
	 }
	
	 public ResponseEntity<Product> updateProduct(int productId,Product pdt) { 
		  Product pdtupdate=productRepo.findById(productId)
				  .orElseThrow(()->new ResourceNotFoundException("Product does not exist with ID : "+ productId));
		  pdtupdate.setProductName(pdt.getProductName());
		  pdtupdate.setPrice(pdt.getPrice());
		  pdtupdate.setColor(pdt.getColor());
		  pdtupdate.setManufacturer(pdt.getManufacturer());
		  pdtupdate.setQuantity(pdt.getQuantity());
		
		  Product updatedProduct=productRepo.save(pdtupdate);
		  return ResponseEntity.ok(updatedProduct); 
		  }

	 public ResponseEntity<Product> viewProduct(int productId) {
		  Product pdtview=productRepo.findById(productId)
				  .orElseThrow(()->new ResourceNotFoundException("Product does not exist with ID : "+ productId));
		  return ResponseEntity.ok(pdtview) ;
		  }

	 public ResponseEntity<Map<String,Boolean>> removeProduct(int productId){
	 		Product pdtremove=productRepo.findById(productId)
	 				  .orElseThrow(()->new ResourceNotFoundException("Product does not exist with ID : "+ productId));
	 		  productRepo.delete(pdtremove);
	 		  Map<String,Boolean> response=new HashMap<>();
	 		  response.put("Product record deleted",Boolean.TRUE);
	 		  return ResponseEntity.ok(response) ;
	  }

}
