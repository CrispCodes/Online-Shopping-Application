package com.cg.onlineshoppingApplication.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.onlineshoppingApplication.entities.Customer;
import com.cg.onlineshoppingApplication.entities.Order;
import com.cg.onlineshoppingApplication.exception.ResourceNotFoundException;
import com.cg.onlineshoppingApplication.repository.ICustomerRepository;
import com.cg.onlineshoppingApplication.repository.IOrderRepository;

@Service
//annotation is used with classes that provide some business functionalities.
@Transactional
public class IOrderServiceImpl implements IOrderService {
	

	//Autowiring feature of spring framework enables you to inject the object dependency implicitly
	@Autowired
	private IOrderRepository orderRepo;

	@Override
	public Order addOrder(Order order) {
		Order od= orderRepo.save(order);
		return od;
	}


	  @Override 
	  public ResponseEntity<Order> updateOrder(int orderId,Order odr) { 
		  Order odrupdate=orderRepo.findById(orderId)
				  .orElseThrow(()->new ResourceNotFoundException("Order does not exist with ID : "+ orderId));
		  odrupdate.setOrderStatus(odr.getOrderStatus());
		
		  Order updatedOrder=orderRepo.save(odrupdate);
		  return ResponseEntity.ok(updatedOrder); 
		  }
	  
	  
	@Override
	public ResponseEntity<Map<String,Boolean>> removeOrder(int orderId){
 		Order odrremove=orderRepo.findById(orderId)
 				  .orElseThrow(()->new ResourceNotFoundException("order does not exist with ID : "+ orderId));
 		  orderRepo.delete(odrremove);
 		  Map<String,Boolean> response=new HashMap<>();
 		  response.put("Order record deleted",Boolean.TRUE);
 		  return ResponseEntity.ok(response) ;
  }
	
      @Override
	  public ResponseEntity<Order> viewOrder(int orderId) {
	  Order odrview=orderRepo.findById(orderId)
			  .orElseThrow(()->new ResourceNotFoundException("Order does not exist with ID : "+ orderId));
	  return ResponseEntity.ok(odrview) ;
	  }
      @Override
	  public List<Order> ViewAllOrders() {
	  List<Order> viewodr=orderRepo.findAll(); 
	  return viewodr; 
	  }
}