package com.cg.onlineshoppingApplication.controllers;

import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshoppingApplication.entities.Customer;
import com.cg.onlineshoppingApplication.entities.Order;
import com.cg.onlineshoppingApplication.services.IOrderServiceImpl;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;


/*
 * @RestController annotation is used to simplify the creation of RESTful web
 * services. It's a convenient annotation that combines @Controller
 * and @ResponseBody, which eliminates the need to annotate every request
 * handling method of the controller class with the @ResponseBody annotation. It
 * converts the response to JSON or XML
 */
@RestController
@CrossOrigin(origins="*")
public class OrderController {
	
	@Autowired
	//Autowiring feature of spring framework enables you to inject the object dependency implicitly
	private IOrderServiceImpl service;
	
	@RequestMapping(method=RequestMethod.POST,value="/addOrder") ////The annotation is used to map web requests to Spring Controller methods.

	public Order addOrder(@RequestBody Order order)
	{
		return service.addOrder(order);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/updateOrder/{orderId}")
	 public ResponseEntity<Order> updateOrder(@PathVariable int orderId,@RequestBody Order odr) 
	  { 
		  return service.updateOrder(orderId,odr); 
	  }

	
	@RequestMapping(method=RequestMethod.DELETE,value="/deleteOrder/{orderId}")
	  public ResponseEntity<Map<String,Boolean>> removeOrder(@PathVariable int orderId)
	  {
	  return service.removeOrder(orderId);
	  }
	
	@RequestMapping(method=RequestMethod.GET,value="/viewOrder/{orderId}")
	 public ResponseEntity<Order> viewOrder(@PathVariable int orderId) {
		  return service.viewOrder(orderId);
		  }
	
	@RequestMapping(method=RequestMethod.GET,value="/viewOrderList")
	 public List<Order> ViewAllOrders() {
		  return service.ViewAllOrders(); }
}

